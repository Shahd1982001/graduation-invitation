import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import gsap from 'gsap'
import { grad } from '../config/grad.js'
import OvalFrame from './OvalFrame.jsx'
import CalendarCountdown from './CalendarCountdown.jsx'
import RSVPDialog from './RSVPDialog.jsx'

const hide = (e) => { e.currentTarget.style.visibility = 'hidden' }
const COUNT = 4

// 4 إطارات بتقدّم رأسي (snap) + تقدّم تلقائي قابل للإيقاف
export default function Slides({ open, reduce }) {
  const box = useRef(null)
  const [index, setIndex] = useState(0)
  const [paused, setPaused] = useState(false)
  const [modal, setModal] = useState(false)

  // تتبّع الإطار الحالي
  useEffect(() => {
    if (!open) return
    const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && setIndex(+e.target.dataset.i)), { root: box.current, threshold: 0.6 })
    box.current.querySelectorAll('.slide').forEach((s) => io.observe(s))
    return () => io.disconnect()
  }, [open])

  // حركة دخول عناصر الإطار الحالي
  useEffect(() => {
    if (!open || reduce) return
    const slide = box.current.children[index]
    const t = gsap.fromTo(slide.querySelectorAll('[data-a]'), { y: 26, autoAlpha: 0 }, { y: 0, autoAlpha: 1, duration: 1, stagger: 0.14, ease: 'power2.out', overwrite: true })
    return () => t.kill()
  }, [index, open, reduce])

  // زهور تتمايل ونجوم تلمع بهدوء
  useEffect(() => {
    if (!open || reduce) return
    const ctx = gsap.context(() => {
      gsap.to('.fl', { rotation: '+=3', y: '+=6', duration: 4, yoyo: true, repeat: -1, ease: 'sine.inOut', stagger: 0.4 })
      gsap.to('.st', { opacity: 0.25, scale: 0.8, duration: 1.6, yoyo: true, repeat: -1, ease: 'sine.inOut', stagger: 0.3 })
    }, box)
    return () => ctx.revert()
  }, [open, reduce])

  // التقدّم التلقائي
  useEffect(() => {
    if (!open || paused || modal || reduce || index >= COUNT - 1) return
    const id = setTimeout(() => box.current.scrollTo({ top: box.current.children[index + 1].offsetTop, behavior: 'smooth' }), grad.autoAdvanceMs)
    return () => clearTimeout(id)
  }, [open, paused, modal, reduce, index])

  const stop = () => setPaused(true)
  const goto = (i) => { setPaused(true); box.current.scrollTo({ top: box.current.children[i].offsetTop, behavior: reduce ? 'auto' : 'smooth' }) }
  const Fl = ({ c }) => <img className={`fl ${c}`} src="/assets/flower.png" alt="" onError={hide} />
  const St = ({ c }) => <img className={`st ${c}`} src="/assets/stars.png" alt="" onError={hide} />

  return (
    <>
    <div className={`slides${reduce ? ' nomotion' : ''}`} ref={box} tabIndex={0} aria-label="الدعوة"
      onPointerDown={stop} onWheel={stop} onTouchStart={stop} onKeyDown={stop}>
      {/* 1) الخريجة */}
      <section className="slide" data-i="0">
        <Fl c="a" /><Fl c="b" /><St c="s1" />
        <p data-a className="verse">﴿ {grad.verse.text} ﴾<small>{grad.verse.ref}</small></p>
        <OvalFrame className="big">
          <div className="back" />
          <img className="girl" src="/assets/girl.png" alt={`الخريجة ${grad.name}`} onError={hide} />
        </OvalFrame>
        <img data-a className="pearls" src="/assets/pearls.png" alt="" onError={hide} />
        <p data-a className="script">Graduation {grad.year}</p>
        <h1 data-a className="gname">{grad.name}</h1>
        <p data-a className="deg">{grad.degree}<br />{grad.university}</p>
        <p data-a className="joy">{grad.joy}</p>
      </section>

      {/* 2) التاريخ والعدّاد */}
      <section className="slide" data-i="1">
        <Fl c="a sm" /><Fl c="b sm" /><St c="s2" />
        <OvalFrame><div className="back" /><img className="flower-in" src="/assets/flower.png" alt="" onError={hide} /></OvalFrame>
        <CalendarCountdown />
      </section>

      {/* 3) المكان */}
      <section className="slide" data-i="2">
        <Fl c="a sm" /><Fl c="b sm" /><St c="s1" />
        <OvalFrame><div className="back glow" /><img className="candel" src="/assets/candelabra.png" alt="" onError={hide} /></OvalFrame>
        <p data-a className="eyebrow">مكان الحفل</p>
        <h2 data-a className="venue">{grad.placeName}</h2>
        <p data-a className="city">{grad.city}</p>
        <a data-a className="btn-gold" href={grad.mapsUrl} target="_blank" rel="noopener noreferrer">عرض موقع الصالة</a>
      </section>

      {/* 4) الحضور */}
      <section className="slide" data-i="3">
        <Fl c="a" /><Fl c="b" /><St c="s2" />
        <OvalFrame><div className="back" /><img className="stars-in" src="/assets/stars.png" alt="" onError={hide} /></OvalFrame>
        <h2 data-a className="invite">{grad.invite}</h2>
        {grad.notes.map((n) => <p data-a key={n} className="joy">{n}</p>)}
        <button data-a className="btn-gold" onClick={() => setModal(true)}>تأكيد الحضور</button>
        <p data-a className="thanks">{grad.thanks}</p>
      </section>
    </div>
      <button className="pp" onClick={() => setPaused((p) => !p)} aria-label={paused ? 'تشغيل التقدّم التلقائي' : 'إيقاف التقدّم التلقائي مؤقتًا'}>{paused ? '▶' : '❚❚'}</button>
      <nav className="dots" aria-label="الإطارات">
        {Array.from({ length: COUNT }, (_, i) => <button key={i} className={i === index ? 'on' : ''} onClick={() => goto(i)} aria-label={`الإطار ${i + 1}`} aria-current={i === index} />)}
      </nav>
      {modal && createPortal(<RSVPDialog onClose={() => setModal(false)} />, document.body)}
    </>
  )
}
