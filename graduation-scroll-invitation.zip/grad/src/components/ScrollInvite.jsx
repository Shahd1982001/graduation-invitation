import { useEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import Bow from './Bow.jsx'
import Slides from './Slides.jsx'

const hide = (e) => { e.currentTarget.style.visibility = 'hidden' }

// لفافة مقفولة بفيونكة: الضغط عليها يفكّ الفيونكة وتنفتح اللفافة لتكشف الإطارات
export default function ScrollInvite({ reduce }) {
  const root = useRef(null), tl = useRef(null)
  const [phase, setPhase] = useState('closed') // closed | opening | open
  const [open, setOpen] = useState(false)

  useEffect(() => {
    // حركة خفيفة للزينة قبل الفتح
    if (reduce) return
    const ctx = gsap.context(() => {
      gsap.to('.deco .fl', { rotation: '+=3', y: '+=6', duration: 4, yoyo: true, repeat: -1, ease: 'sine.inOut' })
      gsap.to('.deco .st', { opacity: 0.3, scale: 0.8, duration: 1.6, yoyo: true, repeat: -1, ease: 'sine.inOut', stagger: 0.4 })
      gsap.to('.bow', { rotation: 3, duration: 1.8, yoyo: true, repeat: -1, ease: 'sine.inOut', transformOrigin: '50% 45%' })
    }, root)
    return () => ctx.revert()
  }, [reduce])
  useEffect(() => () => tl.current && tl.current.kill(), [])

  const untie = () => {
    if (phase !== 'closed') return
    setPhase('opening')
    const q = gsap.utils.selector(root.current), d = reduce ? 0.3 : 1
    const H = window.innerHeight - 60
    tl.current = gsap.timeline({ defaults: { ease: 'power2.inOut' }, onComplete: () => setPhase('open') })
      .to(q('.hint'), { autoAlpha: 0, duration: 0.4 * d }, 0)
      .to(q('.bow'), { rotation: 18, scale: 1.25, y: -26, autoAlpha: 0, duration: 0.9 * d, overwrite: true }, 0)
      .to(q('.band'), { scaleX: 0, autoAlpha: 0, duration: 0.7 * d }, 0.15 * d)
      .to(q('.deco'), { autoAlpha: 0, duration: 1.2 * d }, 0.9 * d)
      .to(q('.scroll'), { width: window.innerWidth, duration: 2.6 * d }, 0.9 * d)
      .to(q('.sheet'), { height: H, duration: 2.6 * d }, 0.9 * d)
      .add(() => setOpen(true), 1.9 * d)
      .to(q('.roller'), { height: 0, autoAlpha: 0, duration: 0.8 * d }, '>-0.2')
      .to(q('.sheet'), { height: window.innerHeight, duration: 0.8 * d }, '<')
  }

  return (
    <main className={`invite ${phase}`} ref={root}>
      <div className="bgp" aria-hidden="true" />
      <div className="deco" aria-hidden="true">
        <img className="fl a" src="/assets/flower.png" alt="" onError={hide} />
        <img className="fl b" src="/assets/flower.png" alt="" onError={hide} />
        <img className="st s1" src="/assets/stars.png" alt="" onError={hide} />
        <img className="st s2" src="/assets/stars.png" alt="" onError={hide} />
      </div>
      <div className="scroll">
        <div className="roller top" />
        <div className="sheet"><Slides open={open} reduce={reduce} /></div>
        <div className="roller bot" />
        {phase !== 'open' && (
          <button className="tie" onClick={untie} disabled={phase !== 'closed'} aria-label="اضغطي على الفيونكة لفتح الدعوة">
            <span className="band" /><Bow />
          </button>
        )}
      </div>
      <p className="hint" aria-live="polite">اضغطي على الفيونكة</p>
    </main>
  )
}
